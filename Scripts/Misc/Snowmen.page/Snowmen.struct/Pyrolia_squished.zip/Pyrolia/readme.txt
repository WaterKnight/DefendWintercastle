Pyrolia

Description:
Unit from my Sylvan race.

Pyrolia :light ranged unit

Before recieving the sylvan essence the pyrolia was beautiful flower wich growth in volcanic island.The sylvan essence gave it the abilitie to spit a hightly combustable spore.

Skins:
(the skins listed below are not nescessarily in this zip package, they are just a list of the skins used by the model.)Doodads\Outland\Plants\Outland_Plant\plants.blp
Textures\AshenNatural.blp
Buildings\Demon\CorruptedAncientProtector\CorruptedAncientProtector.blp
Textures\Green_Glow3.blp

Downloaded from http://www.hiveworkshop.com