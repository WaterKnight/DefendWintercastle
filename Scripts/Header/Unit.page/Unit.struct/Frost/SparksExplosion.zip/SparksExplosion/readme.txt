SparksExplosion
By WILLTHEALMIGHTY

Description:
From the Hive Workshop's First SFX Contest.

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2008, April 20


Visit http://www.hiveworkshop.com for more downloads