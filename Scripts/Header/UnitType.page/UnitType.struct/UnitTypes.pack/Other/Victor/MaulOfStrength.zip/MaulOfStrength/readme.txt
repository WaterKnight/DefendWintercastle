MaulOfStrength
By Thrikodius

Description:
Sorry for eventual spam. Those models are verry easy to make and can be done in a few hours so everytime I get an idea there is a model a few hours later.

Anyway give credits and all that. Hope you'll like it.

UPDATE: I changed the wrapping to make a little more logical shading since I didn't consider that when I rotated it.
UPDATE 2: Added DARKNESS.

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2009, March 19
Model was last updated 2009, March 20


Visit http://www.hiveworkshop.com for more downloads