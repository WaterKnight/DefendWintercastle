Orc Warlock Hero
By Dojo

Description:
An orc hero I simply called OrcHero because he looks so heroic.^^ He propably seems a liddle bit to noble because of bloodelf cape but I really couldnt find a better matching texture. Just use him as a high class intellectual group leader raise by humans (like thrall) or something.

Edit by General Frank: I added a camera to the main model and a separate portrait model.

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2008, February 10
Model was last updated 2008, April 12


Visit http://www.hiveworkshop.com for more downloads