Orcish Berserker
By supertoinkz

Description:
Oh well
got bored after our finals
this will be used on Alagremm's FoD and my Project and I thought about releasing it

[b]Thanks to[/b]
Creators of Mdlvis
Oinkerwinkle
Argus

Got Inspired by General Frank and Armies of Exigo's Berserker

Update 1: The blood is now Blend, Change the cloth on the pelvis, improved the wrap ( now works with the Mag'har skins in the site), Change the texture of the armlets, added a ring piercing in the nose (har har)
Update 2: optimized with Mdlvis

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2010, March 10
Model was last updated 2010, June 18


Visit http://www.hiveworkshop.com for more downloads