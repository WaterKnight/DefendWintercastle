OrcAssassine
By Linaze

Description:
This is one of my first models. Basically a Female Orc Rogue created via mdl editing and a recolored texture.
*Removed ears.
*Removed wings.
*Removed horns.
*Demon Hunter animations.
*Sylvanas Death &amp; Dissipate animations.
*New weapons.
*Hero glow.
*New skin.
*Added mask.

Big thanks to Tauer for helping me with some things on this model!

[b]Update[/b]: Added team color to the bra and panties.

[b]Please give credits if you use this in your map/campaign, you are free to edit it as you wish as long as you give credit to me.[/b]

Textures:
OrcRogue.blp

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2009, March 23
Model was last updated 2009, March 31


Visit http://www.hiveworkshop.com for more downloads