Hawk Scout
By Hawk Scout

Description:
Well a model i am working on for my map: Stand or Fall. ^^

It is not finished yet and I need your help. What should i change. Propably the weapon? (maybe more look like the one on envenomed spears icon?) I also have problem finding good textures for the pants (around the hips) and the boots. Comment it!

I will update the final version.

Update: Fixed some bugs and added better screenshot.

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2008, March 6
Model was last updated 2008, March 15


Visit http://www.hiveworkshop.com for more downloads