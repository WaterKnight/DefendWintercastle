Pandaren Brewmaster's Rolling Keg
By RetroSexual

Description:
Panaren brewmaster's [COLOR=SandyBrown]rolling keg[/COLOR]:3
[SIZE=4]Animations in Model Editor look weird, but ingame everything is ok[/SIZE]

[COLOR=SandyBrown][SIZE=3]Give credits if you use it, or this keg smashes you[/SIZE][/COLOR]:D


[SIZE="1"]Update: Removed one global sequence, it's not jumping anymore, so it will be more usefull as throwable; improved death animation.[/SIZE]

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2011, December 11
Model was last updated 2012, April 23


Visit http://www.hiveworkshop.com for more downloads