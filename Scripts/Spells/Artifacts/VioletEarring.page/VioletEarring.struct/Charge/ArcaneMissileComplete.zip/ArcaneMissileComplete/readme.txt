Arcane Missile
By Weep

Description:
Arcane Missiles (from WoW, of course) look cool.  I'm surprised nobody's posted one before.  I pieced this one together from modified bits of the Lava Spawn missile, Orb of Corruption missile, and Healing Spray missile.

There weren't really any sounds in WC3 that matched the sound of Arcane Missiles very well, but I did my best.  Suggestions for alternatives are welcome.

Credit when used is not required, but appreciated.  Modification is permitted.

[Update 3/21/10: Tweaked the color, less pink, more purple.]
[Update 3/23/10: Refined particles, cleaned object IDs.]

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2010, March 19
Model was last updated 2010, March 23


Visit http://www.hiveworkshop.com for more downloads