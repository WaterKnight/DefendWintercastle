SpiritArrow_ByEpsilon
By epsilon

Description:
A glowing magic arrow.. requested by gerhalt!

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2012, June 7


Visit http://www.hiveworkshop.com for more downloads