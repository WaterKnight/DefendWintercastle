Darknova
By marcus158

Description:
Yo.



I hope this is better than my other models, kinda junky but useful.

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2008, November 29


Visit http://www.hiveworkshop.com for more downloads