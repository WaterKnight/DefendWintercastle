Ice Incenerate
By s4nji

Description:
Requires Custom Texture : HeroIceLord.blp that I made

I made an animation that is a lot funnier and cooler than the normal birth animation
and the fire texture... I inverted the color and... cool! It's like a Crystal spinning over and over...

by s4nji
Tell me If I had sumthin wrong because this is my first model I created...

Updated 28 Nov : 
1. Particles used reduced from 130 to 70-80

Updated 30 Nov : 
1. Even Reduced the number of particles used from 130 to 70-80 now 
                            60-70
                        2. Reduced Memory used [The texture used]

Updated 15 Mar 2010 : 
Many big changes....
Reduced particle counts
Added Death Anim
Changed some alpha value
Changed birth anim
Removed 2 bones
Removed 1 geoset
Removed 1 Materials
Remade the custom texture
UV Mapped the model

:D :D :D :D :D

Textures:
HeroAvatarIce.blp

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2008, November 27
Model was last updated 2010, March 15


Visit http://www.hiveworkshop.com for more downloads