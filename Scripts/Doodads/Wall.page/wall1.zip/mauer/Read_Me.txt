The Texture have no Path this mean the Path ist only "mauer.blp"

This is a model from my townpack for more doodad�s look at my webside www.rondo.eu.tp