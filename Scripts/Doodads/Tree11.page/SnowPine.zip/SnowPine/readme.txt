SnowPine
By Gottfrei

Description:
This model is my simply adding to wc3 landscapes. heh

Please give ctrdits if you use  it.

Update: add a stump.

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2009, January 23
Model was last updated 2009, January 23


Visit http://www.hiveworkshop.com for more downloads