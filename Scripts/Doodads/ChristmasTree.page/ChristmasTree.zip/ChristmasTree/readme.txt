Christmas tree
By Pyramidhe@d

Description:
MERRY CHRISTMAS :D!!!!
celebrating Hive's christmas

Textures:
straw.blp

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2009, December 24
Model was last updated 2009, December 24


Visit http://www.hiveworkshop.com for more downloads